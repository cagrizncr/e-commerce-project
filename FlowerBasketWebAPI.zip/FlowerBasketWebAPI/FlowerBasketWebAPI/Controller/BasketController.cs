﻿using FlowerBasket.BusinessLayer.Interface;
using FlowerBasket.Model.RequestModel.BasketRequestModel;
using FlowerBasket.Model.ResponseModel.BasketResponseModel;
using FlowerBasketWebAPI.Extension;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlowerBasketWebAPI.Controller
{
    public class BasketController : ControllerBase
    {
        private readonly IBasketService _basketService;

        public BasketController(IBasketService basketService)
        {
            _basketService = basketService;
        }

        [HttpPost]
        [FlowerBasketAuthorize]
        [Route("[action]")]
        public ActionResult<AddBasketResponse> AddBasketItem(AddBasketItemRequest Request)
        {
            return _basketService.AddBasketItem(Request);
        }
    }
}
