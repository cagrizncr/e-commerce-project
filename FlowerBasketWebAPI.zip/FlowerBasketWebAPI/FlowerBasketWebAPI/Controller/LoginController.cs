﻿using FlowerBasket.BusinessLayer.Interface;
using FlowerBasket.Model.RequestModel.LoginRequestModel;
using FlowerBasket.Model.ResponseModel.LoginResponseModel;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlowerBasketWebAPI.Controller
{
    public class LoginController : ControllerBase
    {
        private readonly IUserService _userService;
        public LoginController(IUserService userService)
        {
            _userService = userService;
        }


        [HttpPost]
        [Route("[action]")]
        public ActionResult<LoginResponse> Login(LoginRequest Request)
        {
            return _userService.Login(Request);
        }
    }
}
