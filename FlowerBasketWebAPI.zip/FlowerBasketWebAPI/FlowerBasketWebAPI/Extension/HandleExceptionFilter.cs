﻿using FlowerBasket.Model.ResponseModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlowerBasketWebAPI.Extension
{
    public class HandleExceptionFilter : ExceptionFilterAttribute
    {
        public override void OnException(ExceptionContext context)
        {
            BaseResponse response = new BaseResponse();
            var msg = context.Exception.GetBaseException().Message;

            response.Message = msg;
            response.IsSuccess = false;

            // always return a JSON result
            context.Result = new JsonResult(response);

        }
    }
}
