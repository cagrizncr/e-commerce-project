﻿using AutoMapper;
using FlowerBasket.Entity;
using FlowerBasket.Model.Basket;
using FlowerBasket.Model.ResponseModel.BasketResponseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlowerBasketWebAPI.Helper
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Basket, AddBasketResponse>()
           .ForMember(dest => dest.BasketId, opt => opt.MapFrom(src => src.RecordId))
           .ForMember(dest => dest.BasketItems, opt => opt.MapFrom(src => src.BasketProducts));

            CreateMap<BasketProduct, BasketItem>()
                .ForMember(dest => dest.ProductName, opt => opt.MapFrom(src => src.Product.Name))
                .ForMember(dest => dest.ProductId, opt => opt.MapFrom(src => src.ProductId))
                .ForMember(dest => dest.Quantity, opt => opt.MapFrom(src => src.Quantity));
        }
    }
}
