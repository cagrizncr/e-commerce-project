﻿using FlowerBasket.DAL;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlowerBasketWebAPI.Helper
{
    public class DataGenerator
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new FlowerBasketContext(
                serviceProvider.GetRequiredService<DbContextOptions<FlowerBasketContext>>()))
            {
                #region AddProduct
                if (!context.Products.Any())
                {
                    context.Products.AddRange(
                    new FlowerBasket.Entity.Product
                    {
                        RecordId = 1,
                        Code = "FLOW_1",
                        Description = "2 Dal Beyaz Orkide Çiçeği",
                        Name = "Beyaz Orkide",
                        ImagePath = "https://cdn03.ciceksepeti.com/cicek/at773-1/L/at773-1-8d6d3a720c67e4d-b0c9db73.jpg",
                        Price = 89.99m,
                        Stock = 25
                    },
                    new FlowerBasket.Entity.Product
                    {
                        RecordId = 2,
                        Code = "KIRMIZI_GUL",
                        Description = "Akvaryum Vazoda 7 Kırmızı Gül",
                        Name = "Kırmızı Gül 7 Vazo",
                        ImagePath = "https://cdn03.ciceksepeti.com/cicek/at727-1/L/akvaryum-vazo-icerisinde-gul-buketi-at727-1-1.jpg",
                        Price = 79.99m,
                        Stock = 12
                    },
                    new FlowerBasket.Entity.Product
                    {
                        RecordId = 3,
                        Code = "PAPATYA_KARNAVAL",
                        Description = "Papatya Karnavalı",
                        Name = "Papatya Karnavalı",
                        ImagePath = "https://cdn03.ciceksepeti.com/cicek/at3982-1/L/papatya-karnavali-standart-boy.jpeg",
                        Price = 59.99m,
                        Stock = 3
                    },
                    new FlowerBasket.Entity.Product
                    {
                        RecordId = 4,
                        Code = "KEK_BUKET",
                        Description = "8 Mart Kurabiyeli Kadınlar Günü Kek Buketi",
                        Name = "Kurabiyeli Kek",
                        ImagePath = "https://cdn03.ciceksepeti.com/cicek/gr953-1/L/8-mart-kurabiyeli-kadinlar-gunu-kek-buketi-gr953-1-635925242270719405.jpg",
                        Price = 59.99m,
                        Stock = 1
                    },
                    new FlowerBasket.Entity.Product
                    {
                        RecordId = 5,
                        Code = "LILYUM",
                        Description = "Premium Kutuda Beyaz Lilyumlar",
                        Name = "Lilyum",
                        ImagePath = "https://cdn03.ciceksepeti.com/cicek/at3591-1/L/premium-kutuda-beyaz-lilyumlar-at3591-1-8d6118be1c7990c-58fd79f2.jpg",
                        Price = 79.99m,
                        Stock = 5
                    },
                    new FlowerBasket.Entity.Product
                    {
                        RecordId = 6,
                        Code = "GUL_CIKOLATA",
                        Description = "15 Kırmızı Gül ve Çikolata",
                        Name = "Gül Çikolata",
                        ImagePath = "https://cdn03.ciceksepeti.com/cicek/at3454-1/L/15-kirmizi-gul-ve-spesiyal-cikolata-at3454-1-8d44ea37214991b-818ab171.jpg",
                        Price = 159.99m,
                        Stock = 0
                    });

                    context.SaveChanges();
                }
                #endregion

                #region User
                if (!context.Users.Any())
                {
                    context.Users.AddRange(
                    new FlowerBasket.Entity.User
                    {
                        RecordId = 1,
                        UserName = "Flower",
                        Password = "123456",
                        Name = "Çiçek Sepeti",
                        Surname = "Çiçek Sepeti"
                    });

                    context.SaveChanges();
                }
                #endregion

            }
        }
    }
}
