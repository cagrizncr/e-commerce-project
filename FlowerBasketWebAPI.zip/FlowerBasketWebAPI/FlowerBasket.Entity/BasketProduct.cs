﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace FlowerBasket.Entity
{
  public  class BasketProduct : Base
    {
        [ForeignKey("Product")]
        public decimal ProductId { get; set; }

        public int Quantity { get; set; }

        [ForeignKey("Basket")]
        public decimal BasketId { get; set; }


        public virtual Product Product { get; set; }

        public virtual Basket Basket { get; set; }
    }
}
