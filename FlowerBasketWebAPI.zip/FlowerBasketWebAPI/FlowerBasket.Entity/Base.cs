﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace FlowerBasket.Entity
{
   public class Base
    {
        [Key]
        public decimal RecordId { get; set; }
        public string Code { get; set; }
        public bool Deleted { get; set; } = false;
    }
}
