﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlowerBasket.Entity
{
   public class Basket : Base
    {
        public Basket()
        {
            BasketProducts = new List<BasketProduct>();
        }
        public decimal UserId { get; set; }

        public virtual ICollection<BasketProduct> BasketProducts { get; set; }
    }
}
