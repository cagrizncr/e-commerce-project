﻿using FlowerBasket.Model.RequestModel.BasketRequestModel;
using FlowerBasket.Model.ResponseModel.BasketResponseModel;
using System;
using System.Collections.Generic;
using System.Text;

namespace FlowerBasket.BusinessLayer.Interface
{
  public  interface IBasketService
    {
        AddBasketResponse AddBasketItem(AddBasketItemRequest Request);
    }
}
