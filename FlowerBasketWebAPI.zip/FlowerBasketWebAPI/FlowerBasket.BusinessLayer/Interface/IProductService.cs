﻿using FlowerBasket.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace FlowerBasket.BusinessLayer.Interface
{
   public interface IProductService
    {
        Product GetProduct(decimal recordId);
    }
}
