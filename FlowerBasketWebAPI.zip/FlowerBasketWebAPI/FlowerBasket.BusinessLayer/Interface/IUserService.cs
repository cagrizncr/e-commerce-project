﻿using FlowerBasket.Model.RequestModel.LoginRequestModel;
using FlowerBasket.Model.ResponseModel.LoginResponseModel;
using System;
using System.Collections.Generic;
using System.Text;

namespace FlowerBasket.BusinessLayer.Interface
{
   public interface IUserService
    {
        LoginResponse Login(LoginRequest Request);
    }
}
