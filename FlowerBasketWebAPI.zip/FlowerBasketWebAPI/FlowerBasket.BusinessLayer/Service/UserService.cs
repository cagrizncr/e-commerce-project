﻿using FlowerBasket.BusinessLayer.Interface;
using FlowerBasket.Model.Authentication;
using FlowerBasket.Model.RequestModel.LoginRequestModel;
using FlowerBasket.Model.ResponseModel.LoginResponseModel;
using FlowerBasket.Repository.Interface;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;

namespace FlowerBasket.BusinessLayer.Service
{
   public class UserService : IUserService
    {
        private IUnitOfWork _uow;
        private readonly TokenManagement _tokenManagement;
        public UserService(IUnitOfWork uow, IOptions<TokenManagement> tokenManagement)
        {
            _uow = uow;
            _tokenManagement = tokenManagement.Value;
        }

        public LoginResponse Login(LoginRequest Request)
        {
            LoginResponse response = new LoginResponse();

            var user = _uow.UserRepo.Find(s => s.UserName == Request.UserName && s.Password == Request.Password).FirstOrDefault();
            if (user == null)
                throw new Exception("Kullanıcı adı veya şifre hatalı");

            var token = string.Empty;

            var claim = new[]
            {
                new Claim(ClaimTypes.Name, Request.UserName)
            };
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_tokenManagement.Secret));
            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var jwtToken = new JwtSecurityToken(
                _tokenManagement.Issuer,
                _tokenManagement.Audience,
                claim,
                expires: DateTime.Now.AddMinutes(_tokenManagement.AccessExpiration),
                signingCredentials: credentials
            );

            token = new JwtSecurityTokenHandler().WriteToken(jwtToken);
            response.AuthToken = token;

            return response;
        }
    }
}
