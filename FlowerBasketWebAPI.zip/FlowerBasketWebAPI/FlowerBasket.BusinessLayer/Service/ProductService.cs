﻿using FlowerBasket.BusinessLayer.Interface;
using FlowerBasket.Entity;
using FlowerBasket.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Text;

namespace FlowerBasket.BusinessLayer.Service
{
  public  class ProductService : IProductService
    {
        private IUnitOfWork _uow;
        public ProductService(IUnitOfWork uow)
        {
            _uow = uow;

        }
        public Product GetProduct(decimal recordId)
        {
            return _uow.ProductRepo.GetById(recordId);
        }
    }
}
