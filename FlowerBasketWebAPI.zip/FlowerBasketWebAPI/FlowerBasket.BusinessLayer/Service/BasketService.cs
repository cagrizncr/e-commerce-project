﻿using AutoMapper;
using FlowerBasket.BusinessLayer.Interface;
using FlowerBasket.Entity;
using FlowerBasket.Model.RequestModel.BasketRequestModel;
using FlowerBasket.Model.ResponseModel.BasketResponseModel;
using FlowerBasket.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FlowerBasket.BusinessLayer.Service
{
   public class BasketService : IBasketService
    {
        private IUnitOfWork _uow;
        private IMapper _mapper;
        private IProductService _productService;
        public BasketService(IUnitOfWork uow, IMapper mapper, IProductService productService)
        {
            _uow = uow;
            _mapper = mapper;
            _productService = productService;
        }

        public AddBasketResponse AddBasketItem(AddBasketItemRequest Request)
        {
            AddBasketResponse response = new AddBasketResponse();


            var product = _productService.GetProduct(Request.ProductId);
            if (product == null)
                throw new Exception("Product not found");


            var currentBasket = _uow.BasketRepo.Find(s => s.UserId == Request.UserId && s.RecordId == Request.BasketId).FirstOrDefault();
            BasketProduct currentBasketProduct;
            if (currentBasket == null)
            {
                currentBasket = new FlowerBasket.Entity.Basket { UserId = Request.UserId };
                currentBasketProduct = new BasketProduct { BasketId = currentBasket.RecordId, ProductId = Request.ProductId, Quantity = Request.Quantity };
                currentBasket.BasketProducts.Add(currentBasketProduct);
                _uow.BasketRepo.Insert(currentBasket);

            }
            else
            {
                if (currentBasket.BasketProducts.Any(s => s.ProductId == Request.ProductId))
                {
                    currentBasketProduct = currentBasket.BasketProducts.FirstOrDefault(s => s.ProductId == Request.ProductId);
                    currentBasketProduct.Quantity += Request.Quantity;
                    _uow.BasketProductRepo.Edit(currentBasketProduct);
                }
                else
                {
                    currentBasketProduct = new BasketProduct { BasketId = currentBasket.RecordId, ProductId = Request.ProductId, Quantity = Request.Quantity };
                    _uow.BasketProductRepo.Insert(currentBasketProduct);
                }
            }

            if (currentBasketProduct.Quantity > product.Stock)
                throw new Exception($"Not Enough Stock. Product : {product.Name} , Available Stock : {product.Stock}");

            _uow.Commit();

            var userBasket = _uow.BasketRepo.Find(s => Request.UserId == s.UserId && s.RecordId == currentBasket.RecordId).FirstOrDefault();

            response = _mapper.Map<AddBasketResponse>(userBasket);
            return response;
        }
    }
}
