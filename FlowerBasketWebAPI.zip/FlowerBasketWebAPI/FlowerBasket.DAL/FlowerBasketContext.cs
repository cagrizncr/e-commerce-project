﻿using FlowerBasket.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.InMemory.ValueGeneration.Internal;
using System;
using System.Collections.Generic;
using System.Text;

namespace FlowerBasket.DAL
{
  public  class FlowerBasketContext : DbContext
    {
        public DbSet<Product> Products { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Entity.Basket> Baskets { get; set; }
        public DbSet<Entity.BasketProduct> BasketProduct { get; set; }
        public FlowerBasketContext(DbContextOptions<FlowerBasketContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<Product>().HasQueryFilter(p => !p.Deleted);
            builder.Entity<User>().HasQueryFilter(p => !p.Deleted);
            builder.Entity<Entity.Basket>().HasQueryFilter(p => !p.Deleted);
            builder.Entity<Entity.BasketProduct>().HasQueryFilter(p => !p.Deleted);
            //.HasKey(bp => new { bp.BasketId,bp.ProductId });

            //builder.Entity<BasketProduct>().HasOne(bc => bc.Basket).WithMany(b => b.BasketProducts).HasForeignKey(bc => bc.BasketId);

            //builder.Entity<Entity.Product>().HasMany<BasketProduct>(s => s.BasketProducts).WithOne(s=>s.Product).HasForeignKey(s=>s.ProductId);

            builder.Entity<Entity.Basket>(basket =>
            {
                basket.Property(p => p.RecordId).ValueGeneratedOnAdd().HasValueGenerator<InMemoryIntegerValueGenerator<decimal>>();
            });
            builder.Entity<Entity.BasketProduct>(basket =>
            {
                basket.Property(p => p.RecordId).ValueGeneratedOnAdd().HasValueGenerator<InMemoryIntegerValueGenerator<decimal>>();
            });
        }
    }
}
