﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlowerBasket.Model.RequestModel.BasketRequestModel
{
   public class AddBasketItemRequest
    {
        public decimal UserId { get; set; }
        public decimal ProductId { get; set; }
        public int Quantity { get; set; }
        public decimal? BasketId { get; set; }
    }
}
