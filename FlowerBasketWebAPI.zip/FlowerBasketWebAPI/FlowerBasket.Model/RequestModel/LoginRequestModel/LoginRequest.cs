﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace FlowerBasket.Model.RequestModel.LoginRequestModel
{
  public  class LoginRequest
    {
        [DefaultValue("Flower")]
        public string UserName { get; set; }
        [DefaultValue("123456")]
        public string Password { get; set; }
    }
}
