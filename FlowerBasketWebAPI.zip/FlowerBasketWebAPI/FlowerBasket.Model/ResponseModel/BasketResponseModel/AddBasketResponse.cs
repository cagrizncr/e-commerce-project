﻿using FlowerBasket.Model.Basket;
using System;
using System.Collections.Generic;
using System.Text;

namespace FlowerBasket.Model.ResponseModel.BasketResponseModel
{
   public class AddBasketResponse : BaseResponse
    {
        public AddBasketResponse()
        {
            BasketItems = new List<BasketItem>();
        }
        public decimal BasketId { get; set; }
        public List<BasketItem> BasketItems { get; set; }
    }
}
