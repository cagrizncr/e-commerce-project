﻿using System;

namespace FlowerBasket.Model
{
    public class Class1
    {
    }
}
