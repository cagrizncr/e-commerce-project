﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlowerBasket.Model.Basket
{
   public class BasketItem
    {
        public decimal ProductId { get; set; }
        public string ProductName { get; set; }
        public int Quantity { get; set; }
    }
}
