﻿using FlowerBasket.DAL;
using FlowerBasket.Entity;
using FlowerBasket.Repository.Interface;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace FlowerBasket.Repository.Repository
{
   public class GenericRepository<T> : IGenericRepository<T> where T : Base
    {
        public FlowerBasketContext context;
        public DbSet<T> dbset;
        public GenericRepository(FlowerBasketContext context)
        {
            this.context = context;
            dbset = context.Set<T>();
        }

        public T GetById(decimal id)
        {
            return dbset.Find(id);
        }

        public T GetById(string id)
        {
            return dbset.Find(id);
        }
        public IQueryable<T> GetAll()
        {
            return dbset;
        }

        public void Insert(T entity)
        {
            dbset.Add(entity);
        }


        public void Edit(T entity)
        {
            context.Entry(entity).State = EntityState.Modified;
        }


        public void Delete(T entity)
        {
            entity.Deleted = true;
            context.Entry(entity).State = EntityState.Modified;
        }

        public IQueryable<T> All()
        {
            return dbset.AsNoTracking();
        }

        public IQueryable<T> Find(Expression<Func<T, bool>> predicate)
        {
            return dbset.Where(predicate);
        }

        public bool ExecuteSQL(string query)
        {
            return context.Database.ExecuteSqlCommand(query) > 0;
        }
    }
}
