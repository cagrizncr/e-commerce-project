﻿using FlowerBasket.DAL;
using FlowerBasket.Entity;
using FlowerBasket.Repository.Interface;
using System;
using System.Collections.Generic;
using System.Text;

namespace FlowerBasket.Repository.Repository
{
   public class BasketRepository : GenericRepository<Basket>, IBasketRepository
    {
        public BasketRepository(FlowerBasketContext context) : base(context)
        { }
    }
}
