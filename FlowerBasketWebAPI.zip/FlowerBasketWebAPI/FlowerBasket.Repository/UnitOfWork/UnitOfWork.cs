﻿using FlowerBasket.DAL;
using FlowerBasket.Repository.Interface;
using FlowerBasket.Repository.Repository;
using System;
using System.Collections.Generic;
using System.Text;

namespace FlowerBasket.Repository.UnitOfWork
{
   public class UnitOfWork : IUnitOfWork
    {
        private IProductRepository productRepo { get; set; }

        private IUserRepository userRepo { get; set; }
        private IBasketRepository basketRepo { get; set; }
        private IBasketProductRepository basketProductRepo { get; set; }

        public FlowerBasketContext _dbContext;
        public UnitOfWork(FlowerBasketContext context)
        {
            _dbContext = context;
        }
        public IProductRepository ProductRepo => productRepo == null ? new ProductRepository(_dbContext) : productRepo;
        public IUserRepository UserRepo => userRepo == null ? new UserRepository(_dbContext) : userRepo;
        public IBasketRepository BasketRepo => basketRepo == null ? new BasketRepository(_dbContext) : basketRepo;
        public IBasketProductRepository BasketProductRepo => basketProductRepo == null ? new BasketProductRepository(_dbContext) : basketProductRepo;

        public int Commit()
        {
            return _dbContext.SaveChanges();
        }
    }
}
