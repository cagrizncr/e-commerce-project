﻿using FlowerBasket.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace FlowerBasket.Repository.Interface
{
   public interface IProductRepository : IGenericRepository<Product>
    {
    }
}
