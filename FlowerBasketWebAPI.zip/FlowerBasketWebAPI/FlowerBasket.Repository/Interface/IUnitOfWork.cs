﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FlowerBasket.Repository.Interface
{
  public  interface IUnitOfWork
    {
        IProductRepository ProductRepo { get; }
        IUserRepository UserRepo { get; }
        IBasketRepository BasketRepo { get; }
        IBasketProductRepository BasketProductRepo { get; }
        int Commit();
    }
}
