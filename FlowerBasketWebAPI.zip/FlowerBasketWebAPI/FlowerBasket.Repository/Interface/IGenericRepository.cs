﻿using FlowerBasket.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace FlowerBasket.Repository.Interface
{
  public  interface IGenericRepository<T> where T : Base
    {
        T GetById(decimal id);

        T GetById(string id);

        IQueryable<T> GetAll();

        void Edit(T entity);

        void Insert(T entity);

        void Delete(T entity);

        IQueryable<T> All();

        IQueryable<T> Find(Expression<Func<T, bool>> predicate);

        bool ExecuteSQL(string query);
    }
}
